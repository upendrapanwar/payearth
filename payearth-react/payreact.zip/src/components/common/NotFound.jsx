import React from 'react';

const NotFound = (props) => {
    return <div className="no_data_found">{props.msg}</div>;
}

export default NotFound;