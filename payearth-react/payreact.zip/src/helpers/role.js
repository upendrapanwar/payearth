const role = {
    admin: 'admin',
    seller: 'seller',
    user: 'user'
};

export default role;