export const actionTypes = {
    addToCart: "ADD_TO_CART",
    removeFromCart: "REMOVE_FROM_CART",
    addItemQty: "ADD_ITEM_QTY",
    removeItemQty: "REMOVE_ITEM_QTY",
    addWishlist: "ADD_TO_WISHLIST",
    saveLater:"SAVE_LATER"
}